# Counter v4 - pure CSS count down

A Pen created on CodePen.io. Original URL: [https://codepen.io/MRMP-gaming-mohammad-por/pen/zYevGvV](https://codepen.io/MRMP-gaming-mohammad-por/pen/zYevGvV).

A cylindrical 3D counter made entirely with HTML/CSS. Based on the original: https://codepen.io/OastOne/full/eYMJqMe 

Sorry for incorrect tagging - now removed